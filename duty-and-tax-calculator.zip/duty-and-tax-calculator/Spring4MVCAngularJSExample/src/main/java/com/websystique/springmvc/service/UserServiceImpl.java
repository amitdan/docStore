package com.websystique.springmvc.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.core.MediaType;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.pitneybowes.util.converter.XmlToJsonConverter;
import com.websystique.springmvc.model.Address;
import com.websystique.springmvc.model.Tax;
import com.websystique.springmvc.model.User;

@Service("userService")
public class UserServiceImpl implements UserService{
	
	private static final AtomicLong counter = new AtomicLong();
	
	private static List<User> users;
	
	static{
		users= populateDummyUsers();
	}

	public List<User> findAllUsers() {
		return users;
	}
	
	public User findById(long id) {
		for(User user : users){
			if(user.getId() == id){
				return user;
			}
		}
		return null;
	}
	
	public User findByName(String name) {
		for(User user : users){
			if(user.getUsername().equalsIgnoreCase(name)){
				return user;
			}
		}
		return null;
	}
	
	public void saveUser(User user) {
		user.setId(counter.incrementAndGet());
		users.add(user);
	}

	public void updateUser(User user) {
		int index = users.indexOf(user);
		users.set(index, user);
	}

	public void deleteUserById(long id) {
		
		for (Iterator<User> iterator = users.iterator(); iterator.hasNext(); ) {
		    User user = iterator.next();
		    if (user.getId() == id) {
		        iterator.remove();
		    }
		}
	}

	public boolean isUserExist(User user) {
		return findByName(user.getUsername())!=null;
	}
	
	public void deleteAllUsers(){
		users.clear();
	}

	private static List<User> populateDummyUsers(){
		List<User> users = new ArrayList<User>();
		users.add(new User(counter.incrementAndGet(),"Sam", "NY", "sam@abc.com"));
		users.add(new User(counter.incrementAndGet(),"Tomy", "ALBAMA", "tomy@abc.com"));
		users.add(new User(counter.incrementAndGet(),"Kelly", "NEBRASKA", "kelly@abc.com"));
		return users;
	}
	
	
	public List<Address> findAllSupportedCountriesFrom() {
		final HashMap<String, String> countryFromMap = new HashMap<String, String>();
		List<Address> addresses = new ArrayList<Address>();
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(
				"http://www.dutycalculator.com/api2.1/2bac6dba1354599a/supported-countries/from?display_alpha2_code=1");
		Builder builder = target.request(MediaType.APPLICATION_XML);

		final JSONObject jsonObj = XmlToJsonConverter.toJson(builder.get(String.class));

		// System.out.println(obj.toString());
		JSONObject countries = (JSONObject) jsonObj.get("countries");
		// System.out.println(countries.toString());
		JSONArray countryArray = countries.getJSONArray("country");
		for (int index = 0; index < countryArray.length(); index++) {
			addresses.add(new Address(countryArray.getJSONObject(index).get("content").toString()));
			// System.out.println("Country Code
			// "+countryArray.getJSONObject(index).get("code")+" Country Name
			// "+countryArray.getJSONObject(index).get("content"));
			countryFromMap.putIfAbsent(countryArray.getJSONObject(index).get("content").toString(),
					countryArray.getJSONObject(index).get("code").toString());
		}
		System.out.println(countryFromMap.toString());
		return addresses;
	}
	
	public List<Address> findAllSupportedCountriesTo() {
		final HashMap<String, String> countryToMap = new HashMap<String, String>();
		List<Address> addresses = new ArrayList<Address>();
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(
				"http://www.dutycalculator.com/api2.1/2bac6dba1354599a/supported-countries/to?display_alpha2_code=1");
		
		Builder builder = target.request(MediaType.APPLICATION_XML);

		final JSONObject jsonObj = XmlToJsonConverter.toJson(builder.get(String.class));

		JSONObject countries = (JSONObject) jsonObj.get("countries");
		JSONArray countryArray = countries.getJSONArray("country");
		for (int index = 0; index < countryArray.length(); index++) {
			addresses.add(new Address(countryArray.getJSONObject(index).get("content").toString()));
			countryToMap.putIfAbsent(countryArray.getJSONObject(index).get("content").toString(),
					countryArray.getJSONObject(index).get("code").toString());
		}
		System.out.println(countryToMap.toString());
		return addresses;
	}
	
	public Address isExportSupported(String id) {
		List<Address> addressList = findAllSupportedCountriesFrom();
		for(Address address : addressList){
			if(id.equals(address.getCountry())){
				return address;
			}
		}
		return null;
	}
	
	public Address isImportSupported(String id) {
		List<Address> addressList = findAllSupportedCountriesTo();
		for(Address address : addressList){
			if(id.equals(address.getCountry())){
				return address;
			}
		}
		return null;
	}
	
	public List<Tax> calculateDuty(String from, String to) {
		final HashMap<String, String> countryToMap = new HashMap<String, String>();
		List<String> taxes = new ArrayList<String>();
		Client client = ClientBuilder.newClient();
		List<Tax> taxes1 = new ArrayList<Tax>();
		String url = "http://www.dutycalculator.com/api2.1/2bac6dba1354599a/calculation?classify_by=cat&cat[0]=25&desc[0]=Nike+Air+Jordans&qty[0]=1&value[0]=29.95&shipping=6.25&insurance=1.30&currency=usd";
		String finalUrl = url + "&from="+ from + "&to=" + to;
		
		WebTarget target = client.target(finalUrl);
		
		Builder builder = target.request(MediaType.APPLICATION_XML);

		final JSONObject jsonObj = XmlToJsonConverter.toJson(builder.get(String.class));

		taxes.add(jsonObj.toString());
		System.out.println(countryToMap.toString());
		
		//taxes1.add(new Tax("customs-value", "31.96","EUR"));
		taxes1.add(new Tax("duty", "0","EUR"));
		taxes1.add(new Tax("sales-tax VAT", "6.71","EUR"));
		taxes1.add(new Tax("Total", "6.71","EUR"));
		return taxes1;
	}
}
