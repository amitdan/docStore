package com.pitneybowes.util.converter;

import org.json.JSONObject;
import org.json.XML;

public class XmlToJsonConverter {
	public static JSONObject toJson(final String xml){
		//converting xml to json
		JSONObject obj = XML.toJSONObject(xml);
		//System.out.println(obj.toString());
		return obj;
	}
}
